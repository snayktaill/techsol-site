
import { useState, useEffect } from "react";
import { initializeApp } from "firebase/app";
import { getAuth, signInWithEmailAndPassword, onAuthStateChanged, signOut } from "firebase/auth";
import { getFirestore, collection, getDocs, deleteDoc, doc } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "SUA_API_KEY",
  authDomain: "seu-projeto.firebaseapp.com",
  projectId: "seu-projeto",
  storageBucket: "seu-projeto.appspot.com",
  messagingSenderId: "SENDER_ID",
  appId: "APP_ID"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

export default function Admin() {
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [agendamentos, setAgendamentos] = useState([]);

  const login = async () => {
    try {
      await signInWithEmailAndPassword(auth, email, senha);
    } catch (error) {
      alert("Erro ao logar: " + error.message);
    }
  };

  const logout = async () => {
    await signOut(auth);
  };

  const carregarAgendamentos = async () => {
    const snapshot = await getDocs(collection(db, "agendamentos"));
    const dados = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    setAgendamentos(dados);
  };

  const deletarAgendamento = async (id) => {
    await deleteDoc(doc(db, "agendamentos", id));
    carregarAgendamentos();
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (usuario) => {
      if (usuario) {
        setUser(usuario);
        carregarAgendamentos();
      } else {
        setUser(null);
        setAgendamentos([]);
      }
    });
    return () => unsubscribe();
  }, []);

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-zinc-900 text-white">
        <h1 className="text-2xl font-bold mb-4">Painel Administrativo</h1>
        <input type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} className="mb-2 p-2 rounded bg-zinc-800" />
        <input type="password" placeholder="Senha" value={senha} onChange={e => setSenha(e.target.value)} className="mb-4 p-2 rounded bg-zinc-800" />
        <button onClick={login} className="bg-blue-600 hover:bg-blue-500 px-4 py-2 rounded">Entrar</button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-zinc-900 text-white p-8">
      <div className="flex justify-between mb-6">
        <h1 className="text-2xl font-bold">Dashboard - Agendamentos</h1>
        <button onClick={logout} className="bg-red-600 px-4 py-2 rounded hover:bg-red-500">Sair</button>
      </div>
      {agendamentos.length === 0 ? (
        <p>Nenhum agendamento encontrado.</p>
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {agendamentos.map(ag => (
            <div key={ag.id} className="bg-zinc-800 p-4 rounded">
              <p><strong>Nome:</strong> {ag.nome}</p>
              <p><strong>Email:</strong> {ag.email}</p>
              <p><strong>Descrição:</strong> {ag.descricao}</p>
              <p><strong>Data:</strong> {new Date(ag.data).toLocaleString()}</p>
              <button onClick={() => deletarAgendamento(ag.id)} className="mt-2 bg-red-600 hover:bg-red-500 px-3 py-1 rounded text-sm">Excluir</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
