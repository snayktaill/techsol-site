export default function App() {
  return <div className="min-h-screen flex items-center justify-center"><h1 className="text-4xl font-bold">Site TechSol em construção</h1></div>;
}